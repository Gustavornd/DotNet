namespace hotsite.Data;

public class Produto{
    public int Id{ get; set;}
    public string? Nome { get; set;}
    public double Preço { get; set;}
    public string? Descr { get; set;}
    public int Quant { get; set;}
}